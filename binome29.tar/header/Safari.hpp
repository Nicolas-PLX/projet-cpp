#ifndef _SAFARI
#define _SAFARI


/* le jeu safari, qui héritera de Jeux */
#endif